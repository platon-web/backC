﻿namespace Demo.Model
{
    public class Department
    {
        public int Id { get; private set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
    }
}