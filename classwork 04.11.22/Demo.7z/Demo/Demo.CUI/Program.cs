﻿using Demo.Data;

namespace Demo.CUI
{
    internal class Program
    {
        public static void Main()
        {
        }
    }
}